%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,0.62,0.625,0.625,0.625,0.626,0.63,0.631,0.636,0.645,0.65,0.66];
 y = [7.4342751322751255,7.4342751322751255,7.435417989417983,7.435417989417983,7.435417989417983,7.435417989417983,7.437851851851844,7.437851851851844,7.443058201058195,7.444328042328037,7.447714285714278,7.452582010582004];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
