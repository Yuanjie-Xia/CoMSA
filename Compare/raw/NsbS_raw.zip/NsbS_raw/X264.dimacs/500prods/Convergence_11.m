%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,0.9,0.906,0.917,0.924,0.93,0.93,0.931,0.936,0.942,0.942,0.948,0.953,0.953,0.954,0.959];
 y = [7.385153439153434,7.391883597883593,7.395058201058198,7.410455026455023,7.419661375661373,7.421566137566134,7.421566137566134,7.421566137566134,7.425375661375658,7.430455026455024,7.430455026455024,7.432994708994706,7.437566137566136,7.437566137566136,7.437566137566136,7.439259259259258];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
