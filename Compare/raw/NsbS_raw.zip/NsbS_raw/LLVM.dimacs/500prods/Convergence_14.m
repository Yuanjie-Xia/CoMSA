%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.272,1.273,1.281,1.281,1.282,1.283,1.284,1.284,1.285,1.285,1.286];
 y = [13.736222222222187,13.736222222222187,13.736222222222187,13.740888888888854,13.740888888888854,13.740888888888854,13.740888888888854,13.740888888888854,13.740888888888854,13.740888888888854,13.740888888888854,13.740888888888854];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
