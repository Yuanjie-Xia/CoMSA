%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.698,1.699,1.7,1.702,1.702,1.703,1.703,1.704,1.707,1.712,1.712];
 y = [13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744,13.765777777777744];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
