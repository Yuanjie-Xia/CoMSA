%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.428,1.428,1.429,1.433,1.433,1.433,1.434,1.434,1.434,1.434,1.435];
 y = [13.775444444444407,13.775444444444407,13.775444444444407,13.775444444444407,13.787888888888851,13.787888888888851,13.787888888888851,13.787888888888851,13.787888888888851,13.787888888888851,13.787888888888851,13.787888888888851];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
