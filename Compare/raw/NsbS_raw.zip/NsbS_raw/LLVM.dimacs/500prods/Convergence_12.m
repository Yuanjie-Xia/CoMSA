%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.532,1.533,1.533,1.538,1.539,1.539,1.54,1.54,1.54,1.541,1.542,1.542,1.542,1.543,1.543];
 y = [13.78911111111108,13.78911111111108,13.78911111111108,13.78911111111108,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301,13.774333333333301];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
