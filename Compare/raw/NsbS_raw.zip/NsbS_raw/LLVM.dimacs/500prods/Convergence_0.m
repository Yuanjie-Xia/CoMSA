%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.41,1.454,1.455,1.455,1.456,1.457,1.458,1.459,1.459,1.46,1.461];
 y = [13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852,13.769888888888852];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
