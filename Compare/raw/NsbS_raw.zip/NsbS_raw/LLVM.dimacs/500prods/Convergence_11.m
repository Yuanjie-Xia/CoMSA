%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.45,1.451,1.451,1.452,1.453,1.454,1.455,1.456,1.457,1.458,1.458];
 y = [13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219,13.70222222222219];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
