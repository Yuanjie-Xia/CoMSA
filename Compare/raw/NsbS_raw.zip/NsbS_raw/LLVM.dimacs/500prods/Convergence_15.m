%% Plots for convergence
clear 
clc 
set(gcf,'Position',[500 200 500 400])
if get(gca,'Position') <= [inf inf 400 400]
    Size = [3 5 .8 18];
else
    Size = [6 3 2 18];
end
set(gca,'NextPlot','add','Box','on','Fontname','Times New Roman','FontSize',Size(4),'LineWidth',1.3);
 x = [0.0,1.026,1.026,1.027,1.027,1.028,1.028,1.029,1.029,1.03,1.03,1.03];
 y = [13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191,13.716222222222191];
 plot(x,y,'.r')
 tit = title('Convergence');
set(tit,'fontsize',20)

xl = xlabel('Time (s)');
set(xl,'fontsize',20)
yl = ylabel(' Novelty score');
set(yl,'fontsize',20)
